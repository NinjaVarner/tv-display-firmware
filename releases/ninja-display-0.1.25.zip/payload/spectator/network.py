"""Client for the root-owned, restricted NetworkManager helper."""

from __future__ import annotations

import asyncio
import json
import logging
import time
import os


HELPER = "/usr/lib/ninja-display/network-helper"


async def request(operation: str, **values):
    started = time.monotonic()
    payload = json.dumps({"operation": operation, **values}).encode("utf-8")
    process = await asyncio.create_subprocess_exec(
        "sudo", "-n", HELPER,
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        output, diagnostic = await process.communicate(payload)
    except asyncio.CancelledError:
        if process.returncode is None:
            try:
                process.kill()
            except ProcessLookupError:
                pass
        await process.wait()
        raise
    logging.info("Network helper %s completed in %.3f seconds (exit %s)", operation, time.monotonic()-started, process.returncode)
    # Forward only our allowlisted stage constants, never arbitrary stderr.
    import re
    for line in diagnostic.decode("utf-8", errors="replace").splitlines():
        if re.fullmatch(r"NETWORK_STAGE=[A-Z_]{1,64}", line):
            logging.warning("Network helper %s %s", operation, line)
    try:
        result = json.loads(output.decode("utf-8"))
    except (ValueError, UnicodeError):
        raise RuntimeError("network helper unavailable")
    if process.returncode != 0 and not (isinstance(result, dict) and result.get("ok") is False):
        raise RuntimeError("network helper unavailable")
    return result


async def cached_scan() -> list[dict]:
    return (await request("cachedScan")).get("networks", [])


async def scan() -> list[dict]:
    return (await request("scan")).get("networks", [])


async def add(ssid: str, password: str | None) -> dict:
    if not isinstance(ssid, str) or not ssid or len(ssid.encode("utf-8")) > 32:
        raise ValueError("SSID must be 1-32 UTF-8 bytes")
    if password is not None and (not isinstance(password, str) or len(password) > 63):
        raise ValueError("unsupported Wi-Fi password")
    return await request("add", ssid=ssid, password=password)


async def status() -> dict:
    try:
        return await request("status")
    except (OSError, RuntimeError, json.JSONDecodeError):
        return {"connected": False, "reason": "NETWORK_SERVICE_UNAVAILABLE"}
