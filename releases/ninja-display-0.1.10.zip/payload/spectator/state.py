"""Validated spectator state; the Android app remains the race authority."""

from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
import math
import time
from typing import Any


PROTOCOL_VERSION = 1
STATES = {"READY", "RUNNING", "PAUSED", "FINISHED"}
TIMER_MODES = {"ELAPSED", "REMAINING"}
MAX_SNAPSHOT_AGE_MS = 3000


class ProtocolError(ValueError):
    pass


@dataclass(frozen=True)
class RaceSnapshot:
    race_id: str
    revision: int
    state: str
    timer_mode: str
    timer_ms: int
    reference_phone_ms: int
    cleared: int
    total: int
    athlete: str | None


def parse_message(message: Any) -> RaceSnapshot:
    if (not isinstance(message, dict) or type(message.get("protocol")) is not int or
            message.get("protocol") != PROTOCOL_VERSION):
        raise ProtocolError("unsupported protocol version")
    if message.get("type") != "race.snapshot":
        raise ProtocolError("a complete race.snapshot is required")

    race_id = message.get("raceId")
    revision = message.get("revision")
    state = message.get("state")
    timer = message.get("timer")
    obstacles = message.get("obstacles")
    athlete = message.get("athlete")
    if not isinstance(race_id, str) or not race_id or len(race_id) > 128:
        raise ProtocolError("invalid raceId")
    if type(revision) is not int or revision < 0:
        raise ProtocolError("invalid revision")
    if not isinstance(state, str) or state not in STATES:
        raise ProtocolError("invalid race state")
    if not isinstance(timer, dict) or not isinstance(timer.get("mode"), str) or timer.get("mode") not in TIMER_MODES:
        raise ProtocolError("invalid timer")
    timer_ms = timer.get("valueMs")
    reference = timer.get("phoneMonotonicMs")
    if type(timer_ms) is not int or not 0 <= timer_ms <= 604_800_000:
        raise ProtocolError("invalid timer value")
    if type(reference) is not int or not 0 <= reference < 2**63:
        raise ProtocolError("invalid timing reference")
    if not isinstance(obstacles, dict):
        raise ProtocolError("invalid obstacle counts")
    cleared = obstacles.get("cleared")
    total = obstacles.get("total")
    if (type(cleared) is not int or type(total) is not int or
            not 0 <= total <= 1_000_000 or not 0 <= cleared <= total):
        raise ProtocolError("invalid obstacle counts")
    if athlete is not None and (
        not isinstance(athlete, str) or len(athlete) > 80 or
        any(ord(character) < 32 or ord(character) == 127 for character in athlete)
    ):
        raise ProtocolError("invalid athlete")

    return RaceSnapshot(
        race_id=race_id,
        revision=revision,
        state=state,
        timer_mode=timer["mode"],
        timer_ms=timer_ms,
        reference_phone_ms=reference,
        cleared=cleared,
        total=total,
        athlete=athlete,
    )


class RaceStore:
    def __init__(self) -> None:
        self.snapshot: RaceSnapshot | None = None
        self.connected = False
        self._phone_to_pi_ms = 0.0
        self._sync_uncertainty_ms = float("inf")
        self._last_snapshot_pi_ms: float | None = None
        self._retired_race_ids: OrderedDict[str, None] = OrderedDict()

    def set_clock_offset(self, phone_to_pi_ms: float, uncertainty_ms: float) -> None:
        self._phone_to_pi_ms = phone_to_pi_ms
        self._sync_uncertainty_ms = max(0.0, uncertainty_ms)

    def clear_clock_sync(self) -> None:
        self._sync_uncertainty_ms = float("inf")

    def accept(self, message: Any, received_pi_ms: float | None = None) -> bool:
        candidate = parse_message(message)
        current = self.snapshot
        if current is not None and candidate.race_id == current.race_id:
            if candidate.revision < current.revision:
                return False
            if candidate.revision == current.revision and candidate != current:
                return False
        elif current is not None:
            if (self.connected and candidate.state != "READY") or candidate.race_id in self._retired_race_ids:
                return False
            self._retired_race_ids[current.race_id] = None
            if len(self._retired_race_ids) > 32:
                self._retired_race_ids.popitem(last=False)
        self.snapshot = candidate
        self.connected = True
        self._last_snapshot_pi_ms = (
            time.monotonic_ns() / 1_000_000 if received_pi_ms is None else received_pi_ms
        )
        return True

    def disconnected(self) -> None:
        self.connected = False

    def is_fresh(self, pi_monotonic_ms: float) -> bool:
        return (
            self.connected and self._last_snapshot_pi_ms is not None and
            0 <= pi_monotonic_ms - self._last_snapshot_pi_ms <= MAX_SNAPSHOT_AGE_MS
        )

    def display(self, pi_monotonic_ms: float) -> dict[str, Any]:
        current = self.snapshot
        if current is None:
            return {"connection": "WAITING", "state": "READY", "timerMs": None}
        fresh = self.is_fresh(pi_monotonic_ms)
        timer_ms: int | None = current.timer_ms
        clock_valid = math.isfinite(self._sync_uncertainty_ms) and self._sync_uncertainty_ms <= 250
        if fresh and current.state == "RUNNING" and clock_valid:
            phone_now_ms = pi_monotonic_ms - self._phone_to_pi_ms
            timer_ms += max(0, int(phone_now_ms - current.reference_phone_ms))
        if current.timer_mode == "REMAINING" and fresh and current.state == "RUNNING" and clock_valid:
            timer_ms = max(0, current.timer_ms - max(0, int(
                pi_monotonic_ms - self._phone_to_pi_ms - current.reference_phone_ms
            )))
        return {
            "connection": "CONNECTED" if fresh else "LOST",
            "state": current.state,
            "timerMode": current.timer_mode,
            "timerMs": None if current.state == "RUNNING" and (not clock_valid or not fresh) else timer_ms,
            "clockUncertaintyMs": self._sync_uncertainty_ms,
            "cleared": current.cleared,
            "total": current.total,
            "athlete": current.athlete,
            "raceId": current.race_id,
            "revision": current.revision,
        }