"""Local device identity and owner credential storage."""

from __future__ import annotations

import base64
import json
import os
import secrets
import uuid
from pathlib import Path
from typing import Any


class DeviceIdentity:
    def __init__(self, path: str) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        if self.path.exists():
            self.data = json.loads(self.path.read_text(encoding="utf-8"))
        else:
            short_id = uuid.uuid4().hex[:8].upper()
            self.data = {
                "deviceId": str(uuid.uuid4()),
                "name": f"Ninja Display {short_id}",
                "ownerKey": None,
            }
            self._save()

    def _save(self) -> None:
        temporary = self.path.with_suffix(".tmp")
        temporary.write_text(json.dumps(self.data), encoding="utf-8")
        os.chmod(temporary, 0o600)
        temporary.replace(self.path)

    @property
    def keys(self) -> list[bytes]:
        values = [self.data.get("ownerKey")] + list(self.data.get("phoneKeys", {}).values())
        return [base64.urlsafe_b64decode(value) for value in values if value]

    @property
    def key(self) -> bytes | None:
        return next(iter(self.keys), None)

    def claim(self, peer: str | None = None) -> bytes:
        # Preserve the existing commissioning API and legacy phone credential.
        if peer is None:
            if self.key is not None:
                raise PermissionError("display already has an owner")
            key = secrets.token_bytes(32)
            self.data["ownerKey"] = base64.urlsafe_b64encode(key).decode("ascii")
        else:
            if not peer.startswith("/") or len(peer) > 256:
                raise ValueError("invalid setup peer")
            phones = self.data.setdefault("phoneKeys", {})
            if peer in phones:
                return base64.urlsafe_b64decode(phones[peer])
            if len(phones) >= 32:
                raise PermissionError("maximum registered phones reached")
            key = secrets.token_bytes(32)
            phones[peer] = base64.urlsafe_b64encode(key).decode("ascii")
        self._save()
        return key

    def verifies(self, proof: str, nonce: str) -> bool:
        import hmac
        # Evaluate every registered key; never send keys or the matching index.
        matches = [hmac.compare_digest(proof, expected_proof(key, nonce, self.data["deviceId"]))
                   for key in self.keys]
        return any(matches)

    def reset_access(self) -> None:
        self.data["ownerKey"] = None
        self.data["phoneKeys"] = {}
        self._save()

    def public(self) -> dict[str, str]:
        return {"deviceId": self.data["deviceId"], "name": self.data["name"]}


def expected_proof(key: bytes, nonce: str, device_id: str) -> str:
    import hashlib
    import hmac

    payload = f"ninja-display-v1:{nonce}:{device_id}".encode("utf-8")
    return hmac.new(key, payload, hashlib.sha256).hexdigest()
