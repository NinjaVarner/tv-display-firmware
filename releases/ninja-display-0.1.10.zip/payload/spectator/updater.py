"""Signed application package validation and atomic release activation."""

from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
import zipfile
from pathlib import Path, PurePosixPath
from typing import Callable


MAX_PACKAGE_BYTES = 128 * 1024 * 1024
MAX_EXTRACTED_BYTES = 192 * 1024 * 1024
SUPPORTED_PROTOCOL = 1
VERSION_PATTERN = re.compile(r"^[0-9]+\.[0-9]+\.[0-9]+(?:[-+][A-Za-z0-9.-]+)?$")


class UpdateError(ValueError):
    pass


def _safe_relative_path(name: str) -> PurePosixPath:
    path = PurePosixPath(name)
    if path.is_absolute() or not path.parts or any(part in {"", ".", ".."} for part in path.parts):
        raise UpdateError("unsafe package path")
    if "\\" in name or "\x00" in name:
        raise UpdateError("unsafe package path")
    return path


def verify_package(package: str | Path, public_key: str | Path, hardware: str = "armv6") -> dict:
    package_path = Path(package)
    if package_path.stat().st_size > MAX_PACKAGE_BYTES:
        raise UpdateError("package exceeds transfer limit")
    try:
        with zipfile.ZipFile(package_path) as archive:
            archive_names = archive.namelist()
            names = set(archive_names)
            if len(names) != len(archive_names):
                raise UpdateError("package contains duplicate paths")
            if "manifest.json" not in names or "manifest.sig" not in names:
                raise UpdateError("package lacks signed manifest")
            if archive.getinfo("manifest.json").file_size > 262144 or archive.getinfo("manifest.sig").file_size > 1024:
                raise UpdateError("signed manifest is too large")
            manifest_bytes = archive.read("manifest.json")
            signature = archive.read("manifest.sig")
    except (zipfile.BadZipFile, KeyError, OSError) as error:
        raise UpdateError("invalid package archive") from error

    with tempfile.TemporaryDirectory(prefix="ninja-signature-") as temporary:
        manifest_file = Path(temporary) / "manifest.json"
        signature_file = Path(temporary) / "manifest.sig"
        manifest_file.write_bytes(manifest_bytes)
        signature_file.write_bytes(signature)
        try:
            result = subprocess.run(
                ["openssl", "pkeyutl", "-verify", "-pubin", "-inkey", str(public_key),
                 "-rawin", "-in", str(manifest_file), "-sigfile", str(signature_file)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                check=False,
            )
        except OSError as error:
            raise UpdateError("OpenSSL signature verifier is unavailable") from error
        if result.returncode != 0:
            raise UpdateError("signature verification failed")

    try:
        manifest = json.loads(manifest_bytes)
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise UpdateError("invalid package manifest") from error
    if not isinstance(manifest, dict) or manifest.get("schema") != 1:
        raise UpdateError("unsupported package manifest")
    version = manifest.get("version")
    if not isinstance(version, str) or not VERSION_PATTERN.fullmatch(version):
        raise UpdateError("invalid version")
    if manifest.get("hardware") != hardware:
        raise UpdateError("package is for incompatible hardware")
    minimum = manifest.get("protocolMin")
    maximum = manifest.get("protocolMax")
    if type(minimum) is not int or type(maximum) is not int or not minimum <= SUPPORTED_PROTOCOL <= maximum:
        raise UpdateError("incompatible race protocol")
    files = manifest.get("files")
    if not isinstance(files, dict) or not files:
        raise UpdateError("manifest has no files")
    expected_names = {"manifest.json", "manifest.sig"}
    total_uncompressed = 0
    with zipfile.ZipFile(package_path) as archive:
        names = set(archive.namelist())
        for name, digest in files.items():
            relative = _safe_relative_path(name)
            if not isinstance(digest, str) or not re.fullmatch(r"[0-9a-f]{64}", digest):
                raise UpdateError("invalid file digest")
            archive_name = "payload/" + relative.as_posix()
            expected_names.add(archive_name)
            try:
                info = archive.getinfo(archive_name)
            except KeyError as error:
                raise UpdateError("manifest file missing from package") from error
            if info.file_size > MAX_PACKAGE_BYTES or info.is_dir():
                raise UpdateError("invalid payload file")
            total_uncompressed += info.file_size
            if total_uncompressed > MAX_EXTRACTED_BYTES:
                raise UpdateError("expanded package exceeds size limit")
            mode = info.external_attr >> 16
            if mode and (mode & 0o170000) == 0o120000:
                raise UpdateError("symbolic links are not allowed in packages")
            hasher = hashlib.sha256()
            with archive.open(info) as payload:
                for block in iter(lambda: payload.read(65536), b""):
                    hasher.update(block)
            if hasher.hexdigest() != digest:
                raise UpdateError("payload integrity check failed")
    if names != expected_names:
        raise UpdateError("package contains unlisted files")
    return manifest


def activate_release(
    release: Path,
    current: Path,
    active_race: Callable[[], bool],
    restart: Callable[[], bool],
    current_release: Callable[[], Path | None] | None = None,
    switch_release: Callable[[Path | None], None] | None = None,
) -> bool:
    if active_race():
        raise UpdateError("race is active")
    previous = current_release() if current_release else (current.resolve() if current.is_symlink() else None)

    def switch(target: Path) -> None:
        if switch_release:
            switch_release(target)
            return
        temporary_link = current.with_name(current.name + ".next")
        if temporary_link.exists() or temporary_link.is_symlink():
            temporary_link.unlink()
        os.symlink(str(target), temporary_link)
        os.replace(temporary_link, current)

    if active_race():
        raise UpdateError("race became active before activation")
    switch(release)
    try:
        if restart():
            return True
    except Exception:
        pass  # Restore the previous release even when restart times out.
    if previous is None:
        if switch_release:
            switch_release(None)
        else:
            current.unlink(missing_ok=True)
    else:
        switch(previous)
    restart()
    return False


def install_package(
    package: str | Path,
    public_key: str | Path,
    releases: str | Path,
    current: str | Path,
    active_race: Callable[[], bool],
    restart: Callable[[], bool],
) -> str:
    manifest = verify_package(package, public_key)
    release_root = Path(releases)
    release_root.mkdir(parents=True, exist_ok=True)
    destination = release_root / manifest["version"]
    if destination.exists():
        raise UpdateError("release version is already installed")
    with zipfile.ZipFile(package) as archive:
        expanded_size = sum(archive.getinfo("payload/" + _safe_relative_path(name).as_posix()).file_size
                            for name in manifest["files"])
    required = expanded_size + 16 * 1024 * 1024
    if shutil.disk_usage(release_root).free < required:
        raise UpdateError("insufficient disk space")
    staging = Path(tempfile.mkdtemp(prefix=".staging-", dir=release_root))
    try:
        with zipfile.ZipFile(package) as archive:
            for name in manifest["files"]:
                relative = _safe_relative_path(name)
                target = staging.joinpath(*relative.parts)
                target.parent.mkdir(parents=True, exist_ok=True)
                with archive.open("payload/" + relative.as_posix()) as source, target.open("wb") as output:
                    shutil.copyfileobj(source, output, length=65536)
                target.chmod(0o755 if relative.suffix in {".sh", ""} else 0o644)
        (staging / "VERSION").write_text(manifest["version"] + "\n", encoding="ascii")
        (staging / "VERSION").chmod(0o644)
        if active_race():
            raise UpdateError("race is active")
        # Root updater uses umask 0077; services still need to traverse the release.
        staging.chmod(0o755)
        for directory in staging.rglob("*"):
            if directory.is_dir():
                directory.chmod(0o755)
        os.replace(staging, destination)
        if not activate_release(destination, Path(current), active_race, restart):
            raise UpdateError("health check failed; previous release restored")
    finally:
        if staging.exists():
            shutil.rmtree(staging)
    return manifest["version"]