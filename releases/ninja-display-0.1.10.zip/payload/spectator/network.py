"""Client for the root-owned, restricted NetworkManager helper."""

from __future__ import annotations

import asyncio
import json
import os


HELPER = "/usr/lib/ninja-display/network-helper"


async def request(operation: str, **values):
    payload = json.dumps({"operation": operation, **values}).encode("utf-8")
    process = await asyncio.create_subprocess_exec(
        "sudo", "-n", HELPER,
        stdin=asyncio.subprocess.PIPE,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.DEVNULL,
    )
    try:
        output, _ = await process.communicate(payload)
    except asyncio.CancelledError:
        if process.returncode is None:
            try:
                process.kill()
            except ProcessLookupError:
                pass
        await process.wait()
        raise
    if process.returncode != 0:
        raise RuntimeError("network helper unavailable")
    return json.loads(output.decode("utf-8"))


async def cached_scan() -> list[dict]:
    return (await request("cachedScan")).get("networks", [])


async def scan() -> list[dict]:
    return (await request("scan")).get("networks", [])


async def add(ssid: str, password: str | None) -> dict:
    if not isinstance(ssid, str) or not ssid or len(ssid.encode("utf-8")) > 32:
        raise ValueError("SSID must be 1-32 UTF-8 bytes")
    if password is not None and (not isinstance(password, str) or len(password) > 63):
        raise ValueError("unsupported Wi-Fi password")
    return await request("add", ssid=ssid, password=password)


async def status() -> dict:
    try:
        return await request("status")
    except (OSError, RuntimeError, json.JSONDecodeError):
        return {"connected": False, "reason": "NETWORK_SERVICE_UNAVAILABLE"}
