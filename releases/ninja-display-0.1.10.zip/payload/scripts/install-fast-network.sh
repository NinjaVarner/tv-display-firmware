#!/bin/bash
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo 'Use sudo.'; exit 1; }
dir=/usr/local/lib/ninja-display-nm-fastpath
unit=/etc/systemd/system/NetworkManager.service.d/91-ninja-fast-generator.conf
if [ "${1:-}" = '--undo' ]; then
  rm -f "$unit"
  systemctl daemon-reload
  echo 'Fast generator override removed. Reboot to restore normal startup.'
  exit 0
fi
[ -x /usr/libexec/netplan/generate ] || exit 1
# This test is limited to the current NetworkManager-only configuration.
if find /run/systemd/network -maxdepth 1 -name '*netplan*' -print 2>/dev/null | grep -q .; then
  echo 'Networkd configuration exists; stopping without changes.'; exit 1
fi
install -d -m 755 "$dir" /etc/systemd/system/NetworkManager.service.d
cat > "$dir/netplan" <<'WRAPPER'
#!/bin/sh
if [ "$1" = generate ] && [ -z "${SNAP:-}" ]; then
  shift
  /usr/libexec/netplan/generate "$@"
  result=$?
  /usr/bin/udevadm control --reload >/dev/null 2>&1 || true
  # NM profile regeneration does not need a systemd unit reload.
  exit "$result"
fi
exec /usr/sbin/netplan "$@"
WRAPPER
chmod 755 "$dir/netplan"
cat > "$unit" <<'UNIT'
[Service]
Environment=PATH=/usr/local/lib/ninja-display-nm-fastpath:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
UNIT
systemctl daemon-reload
echo 'NetworkManager-only fast generator test installed. Reboot to measure.'
echo 'Undo: sudo bash /opt/ninja-display/current/scripts/install-fast-network.sh --undo'
