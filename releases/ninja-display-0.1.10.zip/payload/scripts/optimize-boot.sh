#!/bin/bash
set -euo pipefail
if [ "$(id -u)" -ne 0 ]; then echo 'Run this script with sudo.' >&2; exit 1; fi
marker=/etc/cloud/cloud-init.disabled
backup=/var/lib/ninja-display/boot-optimization-backup
if [ "${1:-}" = '--undo' ]; then
  if [ -f "$backup/created-cloud-disable-marker" ]; then
    rm -f "$marker" "$backup/created-cloud-disable-marker"
    echo 'Cloud initialization restored. Reboot when convenient.'
  else
    echo 'No marker created by this script; nothing changed.'
  fi
  exit 0
fi
uuid=$(nmcli -g GENERAL.CON-UUID device show wlan0)
case "$uuid" in ''|'--') echo 'No active Wi-Fi connection; stopping without changes.' >&2; exit 1;; esac
profile="/etc/netplan/90-NM-$uuid.yaml"
if [ ! -s "$profile" ]; then
  echo 'Active Wi-Fi lacks its expected persistent Netplan profile; stopping without changes.' >&2
  exit 1
fi
# Validate existing configuration without applying it or printing Wi-Fi credentials.
netplan generate > /tmp/ninja-netplan-validation.log 2>&1 || {
  echo 'Netplan validation failed; no startup settings changed.' >&2; exit 1;
}
install -d -m 700 "$backup"
if [ ! -f "$backup/netplan-before.tar" ]; then
  tar -cf "$backup/netplan-before.tar" -C /etc netplan
  chmod 600 "$backup/netplan-before.tar"
fi
if [ ! -e "$marker" ]; then
  touch "$marker" "$backup/created-cloud-disable-marker"
  chmod 644 "$marker"
fi
journalctl -b -u NetworkManager -u cloud-init-main -u cloud-init-local --no-pager -o short-monotonic > "$backup/startup-before.log"
echo 'Cloud initialization disabled for future boots; Wi-Fi profiles preserved.'
echo 'No NetworkManager, Bluetooth, SSH, or display services were disabled.'
echo 'Reboot with: sudo reboot'
echo 'Undo with: sudo bash /opt/ninja-display/current/scripts/optimize-boot.sh --undo'
