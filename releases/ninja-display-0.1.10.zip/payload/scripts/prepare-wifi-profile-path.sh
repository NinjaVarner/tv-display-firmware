#!/bin/sh
# One-time service migration for TVs installed before firmware 0.1.9.
set -eu
[ "$(id -u)" = 0 ] || { echo 'Run with sudo.' >&2; exit 1; }
install -d -o root -g root -m 0755 /run/NetworkManager/system-connections
install -d -o root -g root -m 0755 /etc/systemd/system/ninja-display.service.d
printf '%s\n' 'd /run/NetworkManager/system-connections 0755 root root -' > /etc/tmpfiles.d/ninja-display-network.conf
printf '%s\n' '[Service]' 'ReadWritePaths=/run/NetworkManager/system-connections' > /etc/systemd/system/ninja-display.service.d/network-profile.conf
chmod 0644 /etc/tmpfiles.d/ninja-display-network.conf /etc/systemd/system/ninja-display.service.d/network-profile.conf
systemctl daemon-reload
echo 'Wi-Fi profile permissions prepared. Apply the signed firmware update next.'
