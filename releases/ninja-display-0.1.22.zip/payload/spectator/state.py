"""Validated spectator state; the Android app remains the race authority."""

from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
import math
import time
from typing import Any


PROTOCOL_VERSION = 1
STATES = {"READY", "RUNNING", "PAUSED", "FINISHED"}
TIMER_MODES = {"ELAPSED", "REMAINING"}
MAX_SNAPSHOT_AGE_MS = 3000


class ProtocolError(ValueError):
    pass


@dataclass(frozen=True)
class RaceSnapshot:
    race_id: str
    revision: int
    state: str
    timer_mode: str
    timer_ms: int
    reference_phone_ms: int
    cleared: int
    total: int
    athlete: str | None
    time_limit_ms: int | None = None
    completed: int = 0
    outcome: str | None = None


def parse_message(message: Any) -> RaceSnapshot:
    if (not isinstance(message, dict) or type(message.get("protocol")) is not int or
            message.get("protocol") != PROTOCOL_VERSION):
        raise ProtocolError("unsupported protocol version")
    if message.get("type") != "race.snapshot":
        raise ProtocolError("a complete race.snapshot is required")

    race_id = message.get("raceId")
    revision = message.get("revision")
    state = message.get("state")
    timer = message.get("timer")
    obstacles = message.get("obstacles")
    athlete = message.get("athlete")
    if not isinstance(race_id, str) or not race_id or len(race_id) > 128:
        raise ProtocolError("invalid raceId")
    if type(revision) is not int or revision < 0:
        raise ProtocolError("invalid revision")
    if not isinstance(state, str) or state not in STATES:
        raise ProtocolError("invalid race state")
    if not isinstance(timer, dict) or not isinstance(timer.get("mode"), str) or timer.get("mode") not in TIMER_MODES:
        raise ProtocolError("invalid timer")
    timer_ms = timer.get("valueMs")
    reference = timer.get("phoneMonotonicMs")
    if type(timer_ms) is not int or not 0 <= timer_ms <= 604_800_000:
        raise ProtocolError("invalid timer value")
    if type(reference) is not int or not 0 <= reference < 2**63:
        raise ProtocolError("invalid timing reference")
    if not isinstance(obstacles, dict):
        raise ProtocolError("invalid obstacle counts")
    cleared = obstacles.get("cleared")
    total = obstacles.get("total")
    if (type(cleared) is not int or type(total) is not int or
            not 0 <= total <= 1_000_000 or not 0 <= cleared <= total):
        raise ProtocolError("invalid obstacle counts")
    if athlete is not None and (
        not isinstance(athlete, str) or len(athlete) > 80 or
        any(ord(character) < 32 or ord(character) == 127 for character in athlete)
    ):
        raise ProtocolError("invalid athlete")

    limit = message.get("timeLimitMs")
    if limit is not None and (type(limit) is not int or not 1 <= limit <= 604_800_000):
        raise ProtocolError("invalid course time limit")
    result = message.get("obstacleResult", {"completed": 0, "outcome": None})
    if not isinstance(result, dict):
        raise ProtocolError("invalid obstacle result")
    completed, outcome = result.get("completed"), result.get("outcome")
    if type(completed) is not int or not 0 <= completed <= total or outcome not in (None, "CLEARED", "FAILED"):
        raise ProtocolError("invalid obstacle result")

    return RaceSnapshot(
        race_id=race_id,
        revision=revision,
        state=state,
        timer_mode=timer["mode"],
        timer_ms=timer_ms,
        reference_phone_ms=reference,
        cleared=cleared,
        total=total,
        athlete=athlete, time_limit_ms=limit, completed=completed, outcome=outcome,
    )


class RaceStore:
    def __init__(self) -> None:
        self.snapshot: RaceSnapshot | None = None
        self.connected = False
        self._flash_until_ms = 0.0
        self._flash = 0
        self._phone_to_pi_ms = 0.0
        self._sync_uncertainty_ms = float("inf")
        self._last_snapshot_pi_ms: float | None = None
        self._retired_race_ids: OrderedDict[str, None] = OrderedDict()
        self._timer_value_ms: float | None = None
        self._timer_reference_pi_ms = 0.0
        self._display_value_ms: float | None = None
        self._display_pi_ms = 0.0

    def set_clock_offset(self, phone_to_pi_ms: float, uncertainty_ms: float) -> None:
        # A slow Wi-Fi round trip must not replace an accurate clock sample.
        if not math.isfinite(phone_to_pi_ms) or not math.isfinite(uncertainty_ms) or uncertainty_ms > 250:
            return
        self._phone_to_pi_ms = phone_to_pi_ms
        self._sync_uncertainty_ms = max(0.0, uncertainty_ms)
        if self.snapshot is not None and self.snapshot.state == "RUNNING":
            self._timer_value_ms = self.snapshot.timer_ms
            self._timer_reference_pi_ms = self.snapshot.reference_phone_ms + phone_to_pi_ms

    def clear_clock_sync(self) -> None:
        self._sync_uncertainty_ms = float("inf")

    def accept(self, message: Any, received_pi_ms: float | None = None) -> bool:
        candidate = parse_message(message)
        current = self.snapshot
        if current is not None and candidate.race_id == current.race_id:
            if candidate.revision < current.revision:
                return False
            if candidate.revision == current.revision and candidate != current:
                return False
        elif current is not None:
            if (self.connected and candidate.state != "READY") or candidate.race_id in self._retired_race_ids:
                return False
            self._retired_race_ids[current.race_id] = None
            if len(self._retired_race_ids) > 32:
                self._retired_race_ids.popitem(last=False)
        received = time.monotonic_ns() / 1_000_000 if received_pi_ms is None else received_pi_ms
        if (current is not None and self.is_fresh(received) and current.race_id == candidate.race_id
                and current.state in {"RUNNING", "PAUSED"} and candidate.state in {"RUNNING", "PAUSED", "FINISHED"}
                and candidate.completed > current.completed and candidate.outcome):
            self._flash = 1 if candidate.outcome == "CLEARED" else 2
            self._flash_until_ms = received + 600
        elif current is None or current.race_id != candidate.race_id or candidate.state == "READY" or not self.is_fresh(received):
            self._flash = 0
            self._flash_until_ms = 0
        continuous = (current is not None and current.race_id == candidate.race_id
                      and current.state == candidate.state == "RUNNING"
                      and current.timer_mode == candidate.timer_mode)
        if not continuous:
            self._display_value_ms = None
        if math.isfinite(self._sync_uncertainty_ms):
            self._timer_value_ms = candidate.timer_ms
            self._timer_reference_pi_ms = candidate.reference_phone_ms + self._phone_to_pi_ms
        elif not continuous or self._timer_value_ms is None:
            # Start immediately even before the first clock round trip. Later
            # synchronization slews this presentation toward the phone's time.
            self._timer_value_ms = candidate.timer_ms
            self._timer_reference_pi_ms = received
        self.snapshot = candidate
        self.connected = True
        self._last_snapshot_pi_ms = (
            time.monotonic_ns() / 1_000_000 if received_pi_ms is None else received_pi_ms
        )
        return True

    def disconnected(self) -> None:
        self.connected = False

    def is_fresh(self, pi_monotonic_ms: float) -> bool:
        return (
            self.connected and self._last_snapshot_pi_ms is not None and
            0 <= pi_monotonic_ms - self._last_snapshot_pi_ms <= MAX_SNAPSHOT_AGE_MS
        )

    def display(self, pi_monotonic_ms: float) -> dict[str, Any]:
        current = self.snapshot
        if current is None:
            return {"connection": "WAITING", "state": "READY", "timerMs": None}
        fresh = self.is_fresh(pi_monotonic_ms)
        timer_ms = current.timer_ms
        if current.state == "RUNNING":
            direction = -1 if current.timer_mode == "REMAINING" else 1
            target = max(0.0, (self._timer_value_ms or 0.0) + direction * max(
                0.0, pi_monotonic_ms - self._timer_reference_pi_ms))
            if self._display_value_ms is None:
                shown = target
            else:
                delta = max(0.0, pi_monotonic_ms - self._display_pi_ms)
                predicted = max(0.0, self._display_value_ms + direction * delta)
                # Correct at at most 10% of clock speed: running digits never
                # jump backward/forward because a delayed clock sample arrives.
                adjustment = max(-delta * 0.1, min(delta * 0.1, target - predicted))
                shown = max(0.0, predicted + adjustment)
                if direction < 0:
                    shown = min(self._display_value_ms, shown)
                else:
                    shown = max(self._display_value_ms, shown)
            self._display_value_ms = shown
            self._display_pi_ms = pi_monotonic_ms
            timer_ms = int(shown)
        return {
            "connection": "CONNECTED" if fresh else "LOST",
            "state": current.state,
            "timerMode": current.timer_mode,
            "timerMs": timer_ms,
            "clockUncertaintyMs": self._sync_uncertainty_ms,
            "cleared": current.cleared,
            "total": current.total,
            "athlete": current.athlete,
            "raceId": current.race_id,
            "revision": current.revision,
            "timeLimitMs": current.time_limit_ms,
            "obstacleFlash": self._flash if fresh and pi_monotonic_ms < self._flash_until_ms else 0,
            "obstacleFlashUntilMs": int(self._flash_until_ms) if fresh and pi_monotonic_ms < self._flash_until_ms else 0,
        }

def reconcile_update_status(status, active_state, installed_version, target):
    """Only reconcile missing progress after systemd confirms the transaction exited."""
    if active_state not in {"inactive", "failed"} or status.get("stage") not in {"IDLE", "VERIFYING"}:
        return status
    if target and target == installed_version:
        return {"stage": "SUCCESS", "version": installed_version, "recovered": True}
    if status.get("stage") == "VERIFYING":
        return {"stage": "FAILED", "error": "Updater stopped without a final result; check installed version"}
    return status
