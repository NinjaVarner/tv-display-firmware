"""BlueZ GATT setup transport; credentials require authenticated BLE encryption."""

import asyncio
import json
import logging
import re
import secrets
import time
from typing import Callable
from pathlib import Path

from dbus_next import BusType, DBusError, Variant, MessageType
from dbus_next.aio import MessageBus
from dbus_next.service import PropertyAccess, ServiceInterface, dbus_property, method

from . import network
from .auth import DeviceIdentity
from .security import ProvisioningWindow, SECURE_READ_FLAGS, SECURE_WRITE_FLAGS


SERVICE_UUID = "9f3a0001-7c1d-4e2b-a445-b9c0e9000001"
DEVICE_INFO_UUID = "9f3a0002-7c1d-4e2b-a445-b9c0e9000001"
COMMAND_UUID = "9f3a0003-7c1d-4e2b-a445-b9c0e9000001"
RESULT_UUID = "9f3a0004-7c1d-4e2b-a445-b9c0e9000001"
ROOT = "/com/ninjabuzzer/display"
SERVICE_PATH = ROOT + "/service0"


class GattService(ServiceInterface):
    def __init__(self) -> None:
        super().__init__("org.bluez.GattService1")

    @dbus_property(access=PropertyAccess.READ)
    def UUID(self) -> "s":
        return SERVICE_UUID

    @dbus_property(access=PropertyAccess.READ)
    def Primary(self) -> "b":
        return True


class Characteristic(ServiceInterface):
    def __init__(self, uuid: str, path: str, flags: list[str], value: Callable[[], bytes], write=None, authorize=None) -> None:
        super().__init__("org.bluez.GattCharacteristic1")
        self.uuid = uuid
        self.path = path
        self.flags = flags
        self.value = value
        self.write = write
        self.authorize = authorize

    @dbus_property(access=PropertyAccess.READ)
    def UUID(self) -> "s":
        return self.uuid

    @dbus_property(access=PropertyAccess.READ)
    def Service(self) -> "o":
        return SERVICE_PATH

    @dbus_property(access=PropertyAccess.READ)
    def Flags(self) -> "as":
        return self.flags

    @dbus_property(access=PropertyAccess.READ)
    def Value(self) -> "ay":
        return self.value()

    @method()
    def ReadValue(self, options: "a{sv}") -> "ay":
        if "read" not in self.flags:
            raise DBusError("org.bluez.Error.NotPermitted", "read not permitted")
        if self.authorize:
            self.authorize(options)
        offset_variant = options.get("offset")
        offset = offset_variant.value if offset_variant else 0
        mtu_variant = options.get("mtu")
        mtu = mtu_variant.value if mtu_variant else 512
        data = self.value()
        if offset < 0 or offset > len(data):
            raise DBusError("org.bluez.Error.InvalidOffset", "invalid read offset")
        return data[offset:offset + max(1, mtu - 1)]

    @method()
    async def WriteValue(self, value: "ay", options: "a{sv}") -> "":
        if self.write is None or not ("write" in self.flags or "write-without-response" in self.flags):
            raise DBusError("org.bluez.Error.NotPermitted", "write not permitted")
        if self.authorize:
            self.authorize(options)
        if options.get("offset", Variant("q", 0)).value != 0 or options.get("prepare-authorize", Variant("b", False)).value:
            raise DBusError("org.bluez.Error.NotSupported", "use one MTU-sized write, not reliable/offset writes")
        if len(value) > 512:
            raise DBusError("org.bluez.Error.InvalidValueLength", "request exceeds GATT limit")
        try:
            await self.write(bytes(value))
        except PermissionError as error:
            raise DBusError("org.bluez.Error.NotAuthorized", str(error)) from error
        except (ValueError, RuntimeError) as error:
            raise DBusError("org.bluez.Error.InvalidArguments", str(error)) from error


class ObjectManager(ServiceInterface):
    def __init__(self, objects: dict) -> None:
        super().__init__("org.freedesktop.DBus.ObjectManager")
        self.objects = objects

    @method()
    def GetManagedObjects(self) -> "a{oa{sa{sv}}}":
        result = {}
        for path, interfaces in self.objects.items():
            result[path] = {}
            for interface in interfaces:
                properties = {}
                for prop in interface.introspect().properties:
                    if prop.access in {PropertyAccess.READ, PropertyAccess.READWRITE}:
                        value = getattr(interface, prop.name)
                        signature = prop.type
                        properties[prop.name] = Variant(signature, value)
                result[path][interface.name] = properties
        return result


class Advertisement(ServiceInterface):
    def __init__(self, local_name: str) -> None:
        super().__init__("org.bluez.LEAdvertisement1")
        self.local_name = local_name[-8:]

    @dbus_property(access=PropertyAccess.READ)
    def Type(self) -> "s":
        return "peripheral"

    @dbus_property(access=PropertyAccess.READ)
    def ServiceUUIDs(self) -> "as":
        return [SERVICE_UUID]

    @dbus_property(access=PropertyAccess.READ)
    def LocalName(self) -> "s":
        return self.local_name

    @method()
    def Release(self) -> "":
        return


class PairingAgent(ServiceInterface):
    def __init__(self, provisioner: "BLEProvisioner") -> None:
        super().__init__("org.bluez.Agent1")
        self.provisioner = provisioner

    @method()
    def Release(self) -> "":
        return

    @method()
    async def RequestConfirmation(self, device: "o", passkey: "u") -> "":
        await self._confirm_pairing(device, passkey)

    @method()
    async def DisplayPasskey(self, device: "o", passkey: "u", entered: "q") -> "":
        # LE Legacy uses passkey entry rather than numeric comparison.
        # Display the BlueZ-generated value, never a fixed application PIN.
        await self._confirm_pairing(device, passkey)

    async def _confirm_pairing(self, device, passkey):
        self.provisioner.begin_setup(device)
        self.provisioner.debug("Bluetooth pairing: compare TV code and confirm on phone")
        self.provisioner.display.pairing_code = f"{passkey:06d}"
        self.provisioner.display.pairing_code_until = time.monotonic() + 30
        # BlueZ completes authenticated pairing through the phone's system prompt.
        # Keep the code visible while that prompt is being handled.
        return

    @method()
    def RequestAuthorization(self, device: "o") -> "":
        self.provisioner.begin_setup(device)
        return

    @method()
    def AuthorizeService(self, device: "o", uuid: "s") -> "":
        if uuid.lower() != SERVICE_UUID:
            raise DBusError("org.bluez.Error.Rejected", "unsupported service")
        self.provisioner.begin_setup(device)
        return

    @method()
    def Cancel(self) -> "":
        self.provisioner.end_setup()


class BLEProvisioner:
    def __init__(self, identity: DeviceIdentity, display, cert_fingerprint: str) -> None:
        self.identity = identity
        self.display = display
        self.cert_fingerprint = cert_fingerprint
        self.window = ProvisioningWindow()
        self.result_bytes = b"{}"
        self.bus = None
        self.objects = {}
        self.setup_device = None
        self.result_pages = []
        self.setup_started = 0.0
        self.setup_connected_seen = False
        self.bluez_objects = None
        self.command_task = None

    def debug(self, message: str, error: bool = False) -> None:
        callback = getattr(self.display, "set_debug", None)
        if callback:
            callback(message, error)

    def begin_setup(self, device) -> None:
        if not self.window_open:
            self.window.open_until = float("inf")
            self.setup_started = time.monotonic()
            self.setup_connected_seen = False
            self.setup_device = None
            self.result_bytes = b"{}"
            self.result_pages = []
        if self.setup_device is not None and device != self.setup_device:
            self.debug("BLE BUSY: another phone has a setup connection", error=True)
            raise DBusError("org.bluez.Error.NotAuthorized", "another phone owns this setup connection")
        new_peer = self.setup_device is None
        self.setup_device = device
        if new_peer:
            self.debug("Bluetooth setup connected; ready for Wi-Fi setup")
    def end_setup(self) -> None:
        if self.command_task is not None:
            self.command_task.cancel()
            self.command_task = None
        self.window.open_until = 0
        self.setup_device = None
        self.result_bytes = b"{}"
        self.result_pages = []
        self.display.pairing_code = None
        self.debug("Bluetooth disconnected; setup available for another phone")

    def properties_changed(self, message) -> None:
        if (message.message_type == MessageType.SIGNAL and message.path == self.setup_device
                and message.interface == "org.freedesktop.DBus.Properties" and message.member == "PropertiesChanged"
                and message.body and message.body[0] == "org.bluez.Device1"):
            connected = message.body[1].get("Connected")
            if connected is not None:
                if connected.value:
                    self.setup_connected_seen = True
                else:
                    self.end_setup()

    async def refresh_connection(self) -> None:
        if self.setup_device is not None:
            objects = await self.bluez_objects.call_get_managed_objects()
            device = objects.get(self.setup_device, {}).get("org.bluez.Device1", {})
            connected = device.get("Connected")
            if connected is not None and connected.value:
                self.setup_connected_seen = True
            elif self.setup_connected_seen or time.monotonic() - self.setup_started >= 45:
                self.end_setup()

    async def connection_loop(self) -> None:
        while True:
            await self.refresh_connection()
            await asyncio.sleep(1)

    def require_idle(self) -> None:
        if (getattr(self.display, "active_race", False) and getattr(getattr(self.display, "store", None), "snapshot", None) is not None) or (getattr(self.display, "maintenance_marker", None) and self.display.maintenance_marker.exists()):
            self.debug("SETTINGS BLOCKED: race or firmware update active", error=True)
            raise PermissionError("finish the race or update before changing TV settings")

    def authorize(self, options) -> None:
        device = options.get("device")
        if device is None:
            raise DBusError("org.bluez.Error.NotAuthorized", "missing peer identity")
        # GATT flags require authenticated encryption, including for bonded peers.
        self.begin_setup(device.value)

    def result(self) -> bytes:
        return self.result_bytes if self.window_open else b"{}"

    @property
    def window_open(self) -> bool:
        return self.window.is_open()

    def device_info(self) -> bytes:
        data = {**self.identity.public(), "protocol": 1, "websocketPort": 8765,
                "certificateSha256": self.cert_fingerprint, "setupWindow": True,
                "firmwareVersion": Path("VERSION").read_text().strip(),
                "capabilities": ["diagnostics", "resetWifi", "reboot", "continuousSetup", "asyncSetup", "cachedScan"]}
        return json.dumps(data, separators=(",", ":")).encode()

    async def handle_write(self, raw: bytes) -> None:
        self.window.require_open()
        if len(raw) > 512:
            raise ValueError("request too large")
        try:
            request = json.loads(raw)
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise ValueError("invalid request") from error
        if not isinstance(request, dict):
            raise ValueError("invalid request")
        operation = request.get("operation")
        if self.command_task is not None and not self.command_task.done():
            raise DBusError("org.bluez.Error.InProgress", "setup command still running")
        if request.get("async") is True and operation in {"scan", "cachedScan", "addNetwork", "diagnostics", "resetWifi", "reboot"}:
            request_id = request.get("requestId")
            if not isinstance(request_id,str) or not re.fullmatch(r"[A-Za-z0-9._-]{1,64}",request_id):
                raise ValueError("invalid requestId")
            self.result_pages = []
            self.result_bytes = json.dumps({"requestId":request_id,"pending":True},separators=(",",":")).encode()
            self.command_task = asyncio.create_task(self.complete_command(raw,request_id,operation))
            return  # Acknowledge GATT now; the client polls RESULT outside the ATT deadline.
        await self.execute_write(raw)

    async def complete_command(self, raw: bytes, request_id: str, operation: str) -> None:
        try:
            await asyncio.wait_for(self.execute_write(raw),timeout=90)
        except asyncio.CancelledError:
            raise
        except Exception as error:
            code = "SETUP_TIMEOUT" if isinstance(error,asyncio.TimeoutError) else "SETTINGS_BUSY" if isinstance(error,PermissionError) else "NETWORK_HELPER_FAILED" if isinstance(error,(OSError,RuntimeError)) else "SETUP_INTERNAL_ERROR"
            self.result_pages = []
            self.result_bytes = json.dumps({"requestId":request_id,"error":code},separators=(",",":")).encode()
            self.debug("BLE " + operation.upper() + ": " + code,error=True)
            logging.exception("TV setup operation %s failed",operation)
        finally:
            if self.command_task is asyncio.current_task():
                self.command_task = None

    async def execute_write(self, raw: bytes) -> None:
        self.window.require_open()
        if len(raw) > 512:
            raise ValueError("request too large")
        try:
            request = json.loads(raw)
        except (UnicodeDecodeError, json.JSONDecodeError) as error:
            raise ValueError("invalid request") from error
        if not isinstance(request, dict):
            raise ValueError("invalid request")
        operation = request.get("operation")
        self.debug({"scan": "Scanning nearby Wi-Fi networks", "addNetwork": "Joining selected Wi-Fi network", "claim": "Registering phone access", "resetWifi": "Clearing saved Wi-Fi networks", "reboot": "Preparing TV reboot", "diagnostics": "Reading TV connection report"}.get(operation, "Bluetooth setup request"))
        request_id = request.get("requestId")
        if request_id is not None and (not isinstance(request_id, str) or not re.fullmatch(r"[A-Za-z0-9._-]{1,64}", request_id)):
            raise ValueError("invalid requestId")
        if operation in {"scan", "cachedScan"}:
            try:
                networks = await (network.cached_scan() if operation == "cachedScan" else network.scan())
                networks = networks[:20]
                self.result_pages = [json.dumps({"requestId": request_id, "page": index,
                    "pages": max(1, len(networks)), "networks": [entry]},
                    ensure_ascii=False, separators=(",", ":")).encode()
                    for index, entry in enumerate(networks)] or [json.dumps({"requestId": request_id,
                        "page": 0, "pages": 1, "networks": []}).encode()]
                self.result_bytes = self.result_pages[0]
                self.debug("Wi-Fi scan complete: " + str(len(networks)) + " networks found")
            except Exception:
                self.debug("WI-FI SCAN FAILED: NetworkManager unavailable", error=True)
                self.result_bytes = json.dumps({"requestId": request_id, "error": "SCAN_FAILED"}).encode()
        elif operation == "getResult":
            page = request.get("page")
            if type(page) is not int or not 0 <= page < len(self.result_pages):
                raise ValueError("invalid result page")
            self.result_bytes = self.result_pages[page]
        elif operation == "addNetwork":
            self.require_idle()
            result = await network.add(request.get("ssid"), request.get("password"))
            self.display.wifi_state = {"connected": result.get("ok", False), "reason": result.get("reason")}
            self.debug("Wi-Fi connected" if result.get("ok") else "WI-FI: " + result.get("reason", "CONNECTION_FAILED"), error=not result.get("ok"))
            self.display.wifi_error_until = time.monotonic() + 15
            self.result_bytes = json.dumps({"requestId": request_id, **result}, separators=(",", ":")).encode()
        elif operation == "diagnostics":
            wifi = await network.status()
            response = {"requestId": request_id, "wifi": wifi,
                        "appConnected": bool(getattr(self.display, "authenticated_clients", [])),
                        "raceActive": bool(getattr(self.display, "active_race", False)),
                        "version": Path("VERSION").read_text().strip()}
            self.result_bytes = json.dumps(response, separators=(",", ":")).encode()
            self.debug("TV report ready; Wi-Fi: " + str(wifi.get("reason","UNKNOWN")))
        elif operation in {"resetWifi", "reboot"}:
            self.require_idle()
            result = await network.request("resetWifi" if operation == "resetWifi" else "reboot")
            if operation == "resetWifi" and result.get("ok"):
                self.display.wifi_state = {"connected": False, "reason": "SAVED_NETWORK_UNAVAILABLE"}
            self.result_bytes = json.dumps({"requestId": request_id, **result}, separators=(",", ":")).encode()
        elif operation == "claim":
            if self.setup_device is None:
                raise PermissionError("missing authenticated setup peer")
            key = self.identity.claim(self.setup_device)
            response = {"requestId": request_id, "ownerKey": __import__("base64").urlsafe_b64encode(key).decode(),
                        "deviceId": self.identity.data["deviceId"], "certificateSha256": self.cert_fingerprint}
            self.result_bytes = json.dumps(response, separators=(",", ":")).encode()
        elif operation == "factoryReset":
            self.require_idle()
            if request.get("deviceId") != self.identity.data["deviceId"]:
                raise ValueError("device identity confirmation did not match")
            reset = await network.request("reset")
            self.identity.reset_access()
            for client in tuple(self.display.authenticated_clients):
                await client.close(code=4001, reason="ownership reset")
            self.display.store.disconnected()
            self.result_bytes = json.dumps({"requestId": request_id, **reset}, separators=(",", ":")).encode()
        else:
            raise ValueError("unsupported operation")
        if len(self.result_bytes) > 512:
            raise ValueError("result too large")

    async def start(self) -> None:
        self.bus = await MessageBus(bus_type=BusType.SYSTEM).connect()
        self.bus.add_message_handler(self.properties_changed)
        manager = await self.bus.introspect("org.bluez", "/org/bluez/hci0")
        adapter = self.bus.get_proxy_object("org.bluez", "/org/bluez/hci0", manager)
        properties = adapter.get_interface("org.freedesktop.DBus.Properties")
        await properties.call_set("org.bluez.Adapter1", "Powered", Variant("b", True))
        await properties.call_set("org.bluez.Adapter1", "Pairable", Variant("b", True))
        gatt_manager = adapter.get_interface("org.bluez.GattManager1")
        advertising_manager = adapter.get_interface("org.bluez.LEAdvertisingManager1")

        service = GattService()
        info = Characteristic(DEVICE_INFO_UUID, SERVICE_PATH + "/char0",
                                        SECURE_READ_FLAGS, self.device_info, authorize=self.authorize)
        command = Characteristic(COMMAND_UUID, SERVICE_PATH + "/char1",
                                            SECURE_WRITE_FLAGS, lambda: b"", write=self.handle_write, authorize=self.authorize)
        result = Characteristic(RESULT_UUID, SERVICE_PATH + "/char2",
                                          SECURE_READ_FLAGS, self.result, authorize=self.authorize)
        self.objects = {
            SERVICE_PATH: [service],
            info.path: [info],
            command.path: [command],
            result.path: [result],
        }
        self.bus.export(ROOT, ObjectManager(self.objects))
        for path, interfaces in self.objects.items():
            for interface in interfaces:
                self.bus.export(path, interface)
        await gatt_manager.call_register_application(ROOT, {})

        advertisement = Advertisement(self.identity.data["name"])
        self.bus.export(ROOT + "/advertisement0", advertisement)
        await advertising_manager.call_register_advertisement(ROOT + "/advertisement0", {})

        agent = PairingAgent(self)
        agent_path = ROOT + "/agent"
        self.bus.export(agent_path, agent)
        dbus_intro = await self.bus.introspect("org.freedesktop.DBus", "/org/freedesktop/DBus")
        dbus_proxy = self.bus.get_proxy_object("org.freedesktop.DBus", "/org/freedesktop/DBus", dbus_intro)
        await dbus_proxy.get_interface("org.freedesktop.DBus").call_add_match("type='signal',sender='org.bluez',interface='org.freedesktop.DBus.Properties',member='PropertiesChanged'")
        objects_intro = await self.bus.introspect("org.bluez", "/")
        objects_proxy = self.bus.get_proxy_object("org.bluez", "/", objects_intro)
        self.bluez_objects = objects_proxy.get_interface("org.freedesktop.DBus.ObjectManager")
        agent_manager_intro = await self.bus.introspect("org.bluez", "/org/bluez")
        agent_manager_obj = self.bus.get_proxy_object("org.bluez", "/org/bluez", agent_manager_intro)
        agent_manager = agent_manager_obj.get_interface("org.bluez.AgentManager1")
        await agent_manager.call_register_agent(agent_path, "DisplayYesNo")
        await agent_manager.call_request_default_agent(agent_path)
