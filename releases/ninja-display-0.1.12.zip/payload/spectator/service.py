"""Local spectator endpoint. It accepts snapshots; it never controls a race."""

from __future__ import annotations

import asyncio
import base64
import hashlib
import json
import os
import secrets
import shutil
import socket
import ssl
import struct
import time
from pathlib import Path
from typing import Any

from websockets.asyncio.server import serve
from websockets.exceptions import ConnectionClosed

from . import network
from .auth import DeviceIdentity
from .state import PROTOCOL_VERSION, ProtocolError, RaceStore


WS_PORT = 8765
DISCOVERY_PORT = 38272
DISCOVERY_GROUP = "239.255.76.67"
RENDERER_ADDRESS = ("127.0.0.1", 38273)
DISPLAY_FORMAT = struct.Struct("!BBBBBQII80s7s")
DEBUG_FORMAT = struct.Struct("!100s100s100s")
WIFI_CODES = {
    "CONNECTED": 1,
    "SAVED_NETWORK_UNAVAILABLE": 2,
    "WRONG_PASSWORD": 3,
    "NETWORK_UNAVAILABLE": 4,
    "CONNECTION_FAILED": 5,
    "NETWORK_SERVICE_UNAVAILABLE": 5,
}
RACE_CODES = {"READY": 0, "RUNNING": 1, "PAUSED": 2, "FINISHED": 3}


def certificate_fingerprint(pem: str) -> str:
    """Hash DER leaf bytes, matching Android and TLS peer certificates."""
    return hashlib.sha256(ssl.PEM_cert_to_DER_cert(pem)).hexdigest()


class Discovery(asyncio.DatagramProtocol):
    def __init__(self, identity: DeviceIdentity, certificate_fingerprint: str) -> None:
        self.identity = identity
        self.fingerprint = certificate_fingerprint
        self.transport = None

    def connection_made(self, transport) -> None:
        self.transport = transport
        transport.get_extra_info("socket").setsockopt(
            socket.IPPROTO_IP,
            socket.IP_ADD_MEMBERSHIP,
            socket.inet_aton(DISCOVERY_GROUP) + socket.inet_aton("0.0.0.0"),
        )

    def datagram_received(self, data: bytes, addr) -> None:
        if data != b"NINJA_DISPLAY_DISCOVER_V1":
            return
        payload = {
            **self.identity.public(),
            "protocol": PROTOCOL_VERSION,
            "websocketPort": WS_PORT,
            "certificateSha256": self.fingerprint,
        }
        self.transport.sendto(json.dumps(payload, separators=(",", ":")).encode(), addr)


class SpectatorService:
    def __init__(self) -> None:
        self.identity = DeviceIdentity("/var/lib/ninja-display/device.json")
        self.store = RaceStore()
        self.sync_requests: dict[str, float] = {}
        self.wifi_state: dict[str, Any] = {"connected": False, "reason": "SAVED_NETWORK_UNAVAILABLE"}
        self.renderer = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.client_lock = asyncio.Lock()
        self.active_race = False
        self.debug_enabled = os.environ.get("NINJA_DISPLAY_DEBUG", "1") != "0"
        self.debug_progress = "Starting Bluetooth and Wi-Fi services"
        self.debug_error = ""
        self.pairing_code = None
        self.pairing_code_until = 0.0
        self.ota_file = None
        self.ota_size = 0
        self.ota_received = 0
        self.ota_request_id = None
        self.ota_path = Path("/var/lib/ninja-display/updates/incoming.zip")
        self.authenticated_clients = set()
        self.last_network_check = 0.0
        self.wifi_error_until = 0.0
        self.last_clock_sync_pi_ms = 0.0
        self.maintenance_marker = Path("/run/ninja-display/update-in-progress")

    def set_debug(self, message: str, error: bool = False) -> None:
        # Callers supply fixed stages/error codes; never credential-bearing requests.
        clean = str(message).replace("\n", " ").replace("\r", " ")[:99]
        if error:
            self.debug_error = clean
        else:
            self.debug_progress = clean

    async def send_display(self) -> None:
        pi_now_ms = time.monotonic_ns() / 1_000_000
        view = self.store.display(pi_now_ms)
        wifi_reason = self.wifi_state.get("reason", "SAVED_NETWORK_UNAVAILABLE")
        wifi_code = 0 if self.identity.key is None else WIFI_CODES.get(wifi_reason, 2)
        state_code = RACE_CODES.get(view.get("state", "READY"), 0)
        mode_code = 1 if view.get("timerMode") == "REMAINING" else 0
        has_timer = view.get("timerMs") is not None
        timer = max(0, int(view.get("timerMs") or 0))
        label = (view.get("athlete") or "") if view.get("connection") == "CONNECTED" else self.identity.data["name"]
        athlete = label.encode("utf-8")[:80].decode("utf-8", "ignore").encode("utf-8")
        pairing_code = b""
        # A setup-window placeholder must not cover an authenticated race.
        if self.pairing_code == "------" and self.authenticated_clients:
            self.pairing_code = None
        if self.pairing_code and time.monotonic() < self.pairing_code_until:
            pairing_code = self.pairing_code.encode("ascii", "ignore")[:6]
        elif self.pairing_code:
            self.pairing_code = None
        packet = DISPLAY_FORMAT.pack(
            wifi_code,
            int(view.get("connection") == "CONNECTED"),
            state_code,
            mode_code,
            int(has_timer),
            timer,
            int(view.get("cleared", 0)),
            int(view.get("total", 0)),
            athlete.ljust(80, b"\0"),
            pairing_code.ljust(7, b"\0"),
        )
        if self.debug_enabled:
            wifi = self.wifi_state
            lines = [f"DEBUG  WI-FI: {wifi.get('reason', 'CHECKING')}  IP: {wifi.get('ip') or 'NONE'}",
                     self.debug_progress, "ERROR: " + (self.debug_error or "none")]
            packet += DEBUG_FORMAT.pack(*(line.encode("ascii", "replace")[:99].ljust(100, b"\0") for line in lines))
        self.renderer.sendto(packet, RENDERER_ADDRESS)

    async def render_loop(self) -> None:
        while True:
            now = time.monotonic()
            if now * 1000 - self.last_clock_sync_pi_ms > 6000:
                self.store.clear_clock_sync()
            await self.send_display()
            Path("/run/ninja-display/healthy").write_text(str(time.time()), encoding="ascii")
            await asyncio.sleep(0.1)

    async def network_loop(self) -> None:
        while True:
            current_status = await network.status()
            if time.monotonic() >= self.wifi_error_until or current_status.get("connected"):
                self.wifi_state = current_status
            await asyncio.sleep(10)

    def abort_transfer(self) -> None:
        if self.ota_file:
            self.ota_file.close()
            self.ota_file = None
            self.ota_path.unlink(missing_ok=True)
        self.ota_request_id = None

    async def handle(self, websocket) -> None:
        self.set_debug("App found TV; checking saved phone access")
        if self.identity.key is None:
            self.set_debug("APP REJECTED: display must be enrolled over Bluetooth", error=True)
            await websocket.close(code=4001, reason="display requires setup")
            return
        if self.client_lock.locked():
            self.set_debug("APP BUSY: another phone is using the display", error=True)
            await websocket.close(code=4002, reason="display already in use")
            return
        async with self.client_lock:
            self.set_debug("App connected over Wi-Fi; verifying access key")
            nonce = secrets.token_urlsafe(32)
            await websocket.send(json.dumps({"type": "auth.challenge", "nonce": nonce,
                                             "deviceId": self.identity.data["deviceId"],
                                             "protocol": PROTOCOL_VERSION}))
            try:
                auth = json.loads(await asyncio.wait_for(websocket.recv(), timeout=8))
                if (not isinstance(auth, dict) or auth.get("type") != "auth.proof" or
                        not self.identity.verifies(str(auth.get("proof", "")), nonce)):
                    self.set_debug("AUTH FAILED: saved phone key did not match", error=True)
                    await websocket.close(code=4003, reason="authentication failed")
                    return
            except (asyncio.TimeoutError, json.JSONDecodeError, TypeError):
                self.set_debug("AUTH FAILED: timed out or invalid response", error=True)
                await websocket.close(code=4003, reason="authentication failed")
                return

            self.store.disconnected()
            self.store.clear_clock_sync()
            self.authenticated_clients.add(websocket)
            self.debug_error = ""
            self.set_debug("App authenticated; waiting for race snapshot")
            await websocket.send(json.dumps({"type": "snapshot.request", "protocol": PROTOCOL_VERSION}))
            await self.send_display()
            self.sync_requests.clear()
            try:
                async for raw in websocket:
                    if isinstance(raw, bytes) or len(raw) > 65536:
                        await websocket.close(code=1009, reason="message too large")
                        return
                    try:
                        message = json.loads(raw)
                    except json.JSONDecodeError:
                        await websocket.send(json.dumps({"type": "error", "code": "INVALID_JSON"}))
                        continue
                    response = await self.process_message(message)
                    if response is not None:
                        await websocket.send(json.dumps(response, separators=(",", ":")))
                    await self.send_display()
            finally:
                self.abort_transfer()
                self.authenticated_clients.discard(websocket)
                self.store.disconnected()
                self.set_debug("App disconnected; waiting for reconnection")
                await self.send_display()

    async def process_message(self, message: Any) -> dict | None:
        if not isinstance(message, dict):
            return {"type": "error", "code": "INVALID_MESSAGE"}
        kind = message.get("type")
        if kind == "race.snapshot":
            if self.maintenance_marker.exists() and message.get("state") in {"RUNNING", "PAUSED"}:
                return {"type": "error", "code": "UPDATE_IN_PROGRESS"}
            try:
                accepted = self.store.accept(message, time.monotonic_ns() / 1_000_000)
            except ProtocolError:
                self.set_debug("RACE: invalid snapshot from app", error=True)
                return {"type": "error", "code": "INVALID_SNAPSHOT"}
            if accepted:
                self.set_debug("App connected; race snapshot received: " + self.store.snapshot.state)
                self.active_race = self.store.snapshot.state in {"RUNNING", "PAUSED"}
                self._write_race_marker()
            return None if accepted else {"type": "state.ignored", "reason": "STALE_REVISION"}
        if kind == "clock.pong":
            nonce = message.get("nonce")
            if not isinstance(nonce, str) or len(nonce) > 64:
                return {"type": "error", "code": "INVALID_CLOCK_PONG"}
            pi_send = self.sync_requests.pop(nonce, None)
            phone_receive = message.get("phoneReceiveMonoMs")
            phone_send = message.get("phoneSendMonoMs")
            if (pi_send is None or type(phone_receive) is not int or type(phone_send) is not int
                    or not 0 <= phone_receive <= phone_send < 2**63
                    or phone_send - phone_receive > 1000):
                return {"type": "error", "code": "INVALID_CLOCK_PONG"}
            pi_receive = time.monotonic_ns() / 1_000_000
            phone_midpoint = (phone_receive + phone_send) / 2
            pi_midpoint = (pi_send + pi_receive) / 2
            uncertainty = max(0.0, (pi_receive - pi_send - (phone_send - phone_receive)) / 2)
            self.store.set_clock_offset(pi_midpoint - phone_midpoint, uncertainty)
            self.last_clock_sync_pi_ms = pi_receive
            if uncertainty > 250:
                self.set_debug("CLOCK: timing uncertainty exceeds 250 ms", error=True)
            return {"type": "clock.synced", "uncertaintyMs": round(uncertainty, 1)}
        if kind == "wifi.scan":
            try:
                networks = await network.scan()
                return {"type": "wifi.scan.result", "requestId": message.get("requestId"), "networks": networks}
            except Exception:
                return {"type": "wifi.error", "requestId": message.get("requestId"), "code": "SCAN_FAILED"}
        if kind == "wifi.add":
            try:
                result = await network.add(message.get("ssid"), message.get("password"))
                self.wifi_state = {"connected": result.get("ok", False), "reason": result.get("reason")}
                self.wifi_error_until = time.monotonic() + 15
                return {"type": "wifi.add.result", "requestId": message.get("requestId"), **result}
            except (ValueError, RuntimeError):
                return {"type": "wifi.error", "requestId": message.get("requestId"), "code": "INVALID_OR_FAILED_NETWORK"}
        if kind == "ota.begin":
            if self.maintenance_marker.exists():
                return {"type": "ota.error", "code": "UPDATE_IN_PROGRESS"}
            if not Path("/etc/ninja-display/update-ed25519.pub").is_file():
                return {"type": "ota.error", "code": "SIGNING_KEY_NOT_INSTALLED"}
            size = message.get("size")
            request_id = message.get("requestId")
            if type(size) is not int or size < 1 or size > 128 * 1024 * 1024:
                return {"type": "ota.error", "requestId": message.get("requestId"), "code": "INVALID_SIZE"}
            if not isinstance(request_id, str) or not request_id or len(request_id) > 64:
                return {"type": "ota.error", "code": "INVALID_REQUEST_ID"}
            if not self.store.is_fresh(time.monotonic_ns() / 1_000_000):
                return {"type": "ota.error", "requestId": message.get("requestId"), "code": "RACE_STATE_UNKNOWN"}
            if self.active_race:
                return {"type": "ota.error", "requestId": message.get("requestId"), "code": "RACE_ACTIVE"}
            self.ota_path.parent.mkdir(parents=True, exist_ok=True)
            if shutil.disk_usage(self.ota_path.parent).free < size * 2 + 16 * 1024 * 1024:
                return {"type": "ota.error", "requestId": message.get("requestId"), "code": "INSUFFICIENT_SPACE"}
            if self.ota_file:
                self.ota_file.close()
            try:
                descriptor = os.open(
                    self.ota_path,
                    os.O_WRONLY | os.O_CREAT | os.O_TRUNC | getattr(os, "O_NOFOLLOW", 0),
                    0o600,
                )
                self.ota_file = os.fdopen(descriptor, "wb")
            except OSError:
                return {"type": "ota.error", "requestId": request_id, "code": "TRANSFER_STORAGE_FAILED"}
            self.ota_size = size
            self.ota_received = 0
            self.ota_request_id = request_id
            return {"type": "ota.progress", "requestId": self.ota_request_id, "stage": "RECEIVING", "percent": 0}
        if kind == "ota.chunk":
            if not self.ota_file or message.get("requestId") != self.ota_request_id:
                return {"type": "ota.error", "requestId": message.get("requestId"), "code": "NO_TRANSFER"}
            try:
                chunk = base64.b64decode(message.get("data", ""), validate=True)
            except (ValueError, TypeError):
                return {"type": "ota.error", "requestId": self.ota_request_id, "code": "INVALID_CHUNK"}
            if not chunk or len(chunk) > 45000 or self.ota_received + len(chunk) > self.ota_size:
                return {"type": "ota.error", "requestId": self.ota_request_id, "code": "INVALID_CHUNK"}
            self.ota_file.write(chunk)
            self.ota_received += len(chunk)
            return {"type": "ota.progress", "requestId": self.ota_request_id, "stage": "RECEIVING",
                    "percent": int(self.ota_received * 100 / self.ota_size)}
        if kind == "ota.end":
            if not self.ota_file or message.get("requestId") != self.ota_request_id:
                return {"type": "ota.error", "requestId": message.get("requestId"), "code": "NO_TRANSFER"}
            self.ota_file.flush()
            os.fsync(self.ota_file.fileno())
            self.ota_file.close()
            self.ota_file = None
            if self.ota_received != self.ota_size:
                self.ota_path.unlink(missing_ok=True)
                return {"type": "ota.error", "requestId": self.ota_request_id, "code": "INCOMPLETE_TRANSFER"}
            if self.active_race or not self.store.is_fresh(time.monotonic_ns() / 1_000_000):
                self.ota_path.unlink(missing_ok=True)
                return {"type": "ota.error", "requestId": self.ota_request_id, "code": "RACE_ACTIVE_OR_UNKNOWN"}
            try:
                process = await asyncio.create_subprocess_exec(
                    "sudo", "-n", "systemctl", "--no-block", "start", "ninja-display-ota.service",
                    stdin=asyncio.subprocess.DEVNULL,
                    stdout=asyncio.subprocess.DEVNULL,
                    stderr=asyncio.subprocess.DEVNULL,
                )
                await asyncio.wait_for(process.wait(), timeout=10)
            except (OSError, asyncio.TimeoutError):
                process = None
            if process is None or process.returncode != 0:
                return {"type": "ota.error", "requestId": self.ota_request_id, "code": "UPDATER_UNAVAILABLE"}
            return {"type": "ota.progress", "requestId": self.ota_request_id, "stage": "VERIFYING", "percent": 100}
        if kind == "ota.status":
            try:
                status = json.loads(Path("/var/lib/ninja-display/update-result.json").read_text(encoding="utf-8"))
            except (OSError, json.JSONDecodeError):
                status = {"stage": "IDLE"}
            try:
                installed_version = Path("/opt/ninja-display/current/VERSION").read_text(encoding="ascii").strip()
            except OSError:
                installed_version = "unknown"
            return {"type": "ota.status.result", "installedVersion": installed_version, **status}
        return {"type": "error", "code": "UNKNOWN_MESSAGE"}

    def _write_race_marker(self) -> None:
        marker = Path("/run/ninja-display/race-active")
        marker.parent.mkdir(parents=True, exist_ok=True)
        if self.active_race:
            marker.write_text("unknown" if self.store.snapshot is None else "active", encoding="ascii")
        else:
            marker.unlink(missing_ok=True)

    async def clock_loop(self) -> None:
        while True:
            await asyncio.sleep(2)
            sockets = tuple(self.authenticated_clients)
            for websocket in sockets:
                nonce = secrets.token_urlsafe(12)
                sent = time.monotonic_ns() / 1_000_000
                self.sync_requests[nonce] = sent
                try:
                    await websocket.send(json.dumps({"type": "clock.ping", "nonce": nonce,
                                                     "piSendMonoMs": int(sent)}))
                except ConnectionClosed:
                    self.sync_requests.pop(nonce, None)
            cutoff = time.monotonic_ns() / 1_000_000 - 10000
            self.sync_requests = {key: value for key, value in self.sync_requests.items() if value > cutoff}

    async def run(self) -> None:
        cert_path = Path("/etc/ninja-display/tls.crt")
        key_path = Path("/etc/ninja-display/tls.key")
        fingerprint = certificate_fingerprint(cert_path.read_text(encoding="ascii"))
        Path("/run/ninja-display").mkdir(parents=True, exist_ok=True)
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        context.load_cert_chain(str(cert_path), str(key_path))
        loop = asyncio.get_running_loop()
        from .ble import BLEProvisioner
        provisioner = BLEProvisioner(self.identity, self, fingerprint)
        try:
            await provisioner.start()
        except Exception as error:
            self.set_debug("BLUETOOTH START FAILED: " + type(error).__name__, error=True)
            await self.send_display()
            raise
        self.set_debug("Bluetooth ready; TV available for setup from the app")
        # Until a complete snapshot arrives, conservatively block maintenance.
        self.active_race = True
        self._write_race_marker()
        await loop.create_datagram_endpoint(
            lambda: Discovery(self.identity, fingerprint),
            local_addr=("0.0.0.0", DISCOVERY_PORT),
            allow_broadcast=True,
        )
        async with serve(self.handle, "0.0.0.0", WS_PORT, ssl=context,
                         max_size=65536, ping_interval=15, ping_timeout=10):
            async with asyncio.TaskGroup() as tasks:
                tasks.create_task(provisioner.connection_loop())
                tasks.create_task(self.render_loop())
                tasks.create_task(self.network_loop())
                tasks.create_task(self.clock_loop())


def main() -> None:
    asyncio.run(SpectatorService().run())


if __name__ == "__main__":
    main()
