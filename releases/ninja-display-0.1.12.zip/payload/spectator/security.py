"""Provisioning gates and the only permitted security level for GATT data."""

from __future__ import annotations

import time


SECURE_READ_FLAGS = ["read", "encrypt-authenticated-read"]
SECURE_WRITE_FLAGS = ["write", "encrypt-authenticated-write"]


class ProvisioningWindow:
    def __init__(self, duration_seconds: int = 300) -> None:
        self.duration_seconds = duration_seconds
        self.open_until = 0.0

    def open(self, now: float | None = None) -> None:
        self.open_until = (time.monotonic() if now is None else now) + self.duration_seconds

    def is_open(self, now: float | None = None) -> bool:
        return (time.monotonic() if now is None else now) < self.open_until

    def require_open(self, now: float | None = None) -> None:
        if not self.is_open(now):
            raise PermissionError("setup session expired; reconnect from the app")
